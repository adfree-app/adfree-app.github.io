(function() {
	// src/background.js
	/** Where the app answers. Its address, not its logic. */
	var BASE = "https://yuuki-kagura.github.io/local";
	var PLAN_PATH = "/adfree-plan.json";
	/** How long a prefetched plan may be trusted for the navigation that follows. */
	var PLAN_TTL_MS = 15e3;
	/** Prefetched plans, by `tabId:frameId:url`. */
	var prefetched = /* @__PURE__ */ new Map();
	var keyOf = (details) => `${details.tabId}:${details.frameId}:${details.url}`;
	/** The engine's plan for one URL, or `null` when the app is not answering. */
	async function planFor(url) {
		let host;
		try {
			host = new URL(url).hostname;
		} catch {
			return null;
		}
		const endpoint = `${BASE}${PLAN_PATH}?dmn=${encodeURIComponent(host)}`;
		try {
			const response = await fetch(endpoint, { cache: "no-store" });
			return response.ok ? await response.json() : null;
		} catch {
			return null;
		}
	}
	/** The bytes of one of the app's own assets. */
	async function bodyOf(url) {
		if (!url) return null;
		try {
			const response = await fetch(url, { cache: "no-store" });
			return response.ok ? await response.text() : null;
		} catch {
			return null;
		}
	}
	/**
	* Runs in the page, in its own world, once per navigation.
	*
	* Order matters and it is the app's order: the origin the runtime asks its
	* questions at, the payload it reads first thing, the hiding rules, the
	* runtime itself, then the user scripts, which are written against the
	* helpers the runtime installs.
	*/
	function boot(base, cosmetics, css, runtime, runtimeUrl, scripts) {
		window.__adfree_base = base;
		if (cosmetics) window.__adfree_page = cosmetics;
		if (css) try {
			const sheet = new CSSStyleSheet();
			sheet.replaceSync(css);
			document.adoptedStyleSheets = [...document.adoptedStyleSheets, sheet];
		} catch {
			const style = document.createElement("style");
			style.textContent = css;
			(document.head || document.documentElement).appendChild(style);
		}
		const run = (url, source) => {
			if (!source) return;
			try {
				(0, eval)(source);
			} catch {
				const tag = document.createElement("script");
				tag.src = url;
				(document.head || document.documentElement).appendChild(tag);
			}
		};
		run(runtimeUrl, runtime);
		for (const [url, source] of scripts) run(url, source);
	}
	/** Applies one plan to one frame. */
	async function apply(details, plan) {
		if (!plan || !plan.runtime) return;
		const [css, runtime, ...bodies] = await Promise.all([
			bodyOf(plan.css),
			bodyOf(plan.runtime),
			...(plan.scripts || []).map(bodyOf)
		]);
		const scripts = [];
		(plan.scripts || []).forEach((url, index) => {
			if (bodies[index]) scripts.push([url, bodies[index]]);
		});
		await chrome.scripting.executeScript({
			target: {
				tabId: details.tabId,
				frameIds: [details.frameId]
			},
			world: "MAIN",
			injectImmediately: true,
			func: boot,
			args: [
				plan.base || BASE,
				plan.cosmetics || null,
				css || "",
				runtime || "",
				plan.runtime,
				scripts
			]
		});
	}
	chrome.webNavigation.onBeforeNavigate.addListener((details) => {
		if (details.frameId !== 0) return;
		planFor(details.url).then((plan) => {
			if (plan) prefetched.set(keyOf(details), {
				at: Date.now(),
				plan
			});
		});
	});
	chrome.webNavigation.onCommitted.addListener((details) => {
		if (details.frameId !== 0) return;
		const key = keyOf(details);
		const ready = prefetched.get(key);
		prefetched.delete(key);
		const fresh = ready && Date.now() - ready.at < PLAN_TTL_MS ? ready.plan : null;
		(fresh ? Promise.resolve(fresh) : planFor(details.url)).then((plan) => apply(details, plan)).catch(() => {});
	});
})();
